const slideshow = new Slideshow({
  scenario: [
    { 
      text: 'あいうえおあいうえお',
      size: 5,
      src: 'image1.png',
      position: 'right',
    },
    { 
      text: 'かきくけこ',
      size: 6,
      src: 'image2.png',
      position: 'top',
    },
    {
      text: 'さしすせそさしすせそ',
      src: 'image3.png',
    }
  ],
});