// 文字サイズは画面の横幅に対する割合です。
// 横幅の狭いスマホでは小さくなりすぎるので、大きめにします。
const textSize = window.innerWidth < 600 ? 5 : 3;

const slideshow = new Slideshow({
  scenario: [
    {
      text: 'あいうえおあいうえお',
      size: textSize,
      src: 'image1.png',
      position: 'bottom',
    },
    {
      text: 'かきくけこ',
      size: textSize,
      src: 'image2.png',
      position: 'center',
    },
    {
      text: 'さしすせそさしすせそ',
      size: textSize,
      src: 'image3.png',
      position: 'top',
    },
  ],
});
